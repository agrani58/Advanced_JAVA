package rockeyWoodfirePizza;

public class Pizza {
    private String customerName;
    private String pizzaSize;
    private int toppings;

    public Pizza(String customerName, String pizzaSize, int toppings) {
        this.customerName = customerName;
        this.pizzaSize = pizzaSize;
        this.toppings = toppings;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPizzaSize() {
        return pizzaSize;
    }

    public void setPizzaSize(String pizzaSize) {
        this.pizzaSize = pizzaSize;
    }

    public int getToppings() {
        return toppings;
    }

    public void setToppings(int toppings) {
        this.toppings = toppings;
    }

    @Override
    public String toString() {
        return "Customer: " + customerName + ", Size: " + pizzaSize + ", Toppings: " + toppings;
    }
}
