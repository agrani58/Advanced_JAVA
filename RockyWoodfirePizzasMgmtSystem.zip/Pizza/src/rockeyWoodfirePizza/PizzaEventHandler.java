package rockeyWoodfirePizza;

import java.awt.*;
import javax.swing.JOptionPane;
import java.util.ArrayList;

public class PizzaEventHandler {
    private ArrayList<Pizza> pizzaList;
    private TextField nameField;
    private TextField toppingsField;
    private CheckboxGroup sizeGroup;
    private TextArea billTextArea;
    private Frame frame;

    public PizzaEventHandler(TextField nameField, TextField toppingsField, CheckboxGroup sizeGroup, TextArea billTextArea, Frame frame) {
        this.pizzaList = new ArrayList<>();
        this.nameField = nameField;
        this.toppingsField = toppingsField;
        this.sizeGroup = sizeGroup;
        this.billTextArea = billTextArea;
        this.frame = frame;
    }

    public void handleEnter() {
        String customerName = nameField.getText();
        String pizzaSize = sizeGroup.getSelectedCheckbox().getLabel();
        int numToppings;

        try {
            numToppings = Integer.parseInt(toppingsField.getText());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number of toppings.");
            return;
        }

        // Create new Pizza object and add to the list
        Pizza pizza = new Pizza(customerName, pizzaSize, numToppings);
        pizzaList.add(pizza);

        // Display the new pizza in the bill text area
        billTextArea.append(pizza.toString() + "\n");

        // Clear input fields
        nameField.setText("");
        toppingsField.setText("");
    }

    public void handleDisplayAll() {
        StringBuilder bill = new StringBuilder();
        for (Pizza pizza : pizzaList) {
            bill.append(pizza.toString()).append("\n");
        }
        billTextArea.setText(bill.toString());
    }

    public void handleExit() {
        frame.dispose();
    }

    public void handleSearch(String customerName) {
        StringBuilder result = new StringBuilder();
        for (Pizza pizza : pizzaList) {
            if (pizza.getCustomerName().equalsIgnoreCase(customerName)) {
                result.append(pizza.toString()).append("\n");
            }
        }
        if (result.length() == 0) {
            result.append("No orders found for customer: ").append(customerName);
        }
        billTextArea.setText(result.toString());
    }
}
