package rockeyWoodfirePizza;

import java.awt.*;
import java.awt.event.*;

public class RockyWoodfirePizzaManagementSystem {
    public static void main(String[] args) {
        Frame frame = new Frame("Rocky Woodfired Pizza Management System");
        frame.setSize(700, 500); // Increased height to accommodate the bill section and buttons

        // Main panel with null layout
        Panel panel = new Panel(null);
        panel.setBackground(Color.LIGHT_GRAY);
        frame.add(panel);

        Label label = new Label("Rocky Woodfired Pizza Management System");
        label.setBounds(10, 10, 600, 50);
        Font font = new Font("TimesNewRoman", Font.PLAIN, 30);
        label.setFont(font);
        panel.add(label);

        Label name = new Label("Customer Name :");
        name.setBounds(50, 100, 150, 50);
        Font font1 = new Font("TimesNewRoman", Font.PLAIN, 16);
        name.setFont(font1);
        panel.add(name);

        TextField name1 = new TextField();
        name1.setBounds(200, 100, 400, 40);
        panel.add(name1);

        Label topping = new Label("Number of Toppings");
        topping.setBounds(50, 150, 150, 50);
        topping.setFont(font1);
        panel.add(topping);

        TextField toppings = new TextField();
        toppings.setBounds(200, 150, 120, 40);
        panel.add(toppings);

        // Create radio buttons
        CheckboxGroup sizeGroup = new CheckboxGroup();
        Checkbox small = new Checkbox("Small", sizeGroup, false);
        Checkbox medium = new Checkbox("Medium", sizeGroup, true);
        Checkbox large = new Checkbox("Large", sizeGroup, false);

        // Set bounds for radio buttons
        int checkboxY = 160;
        small.setBounds(350, checkboxY, 80, 20); // Adjusted width
        medium.setBounds(440, checkboxY, 80, 20); // Adjusted width
        large.setBounds(530, checkboxY, 80, 20); // Adjusted width
        panel.add(small);
        panel.add(medium);
        panel.add(large);

        // Bill panel with white background
        Panel billPanel = new Panel(null);
        billPanel.setBackground(Color.WHITE);
        billPanel.setBounds(10, 210, 660, 150); // Adjusted size and position
        panel.add(billPanel);

        // Text area to display pizza orders
        TextArea billTextArea = new TextArea();
        billTextArea.setBounds(10, 10, 640, 130);
        billTextArea.setEditable(false);
        billPanel.add(billTextArea);

        // Buttons
        Button enterButton = new Button("Enter");
        enterButton.setBounds(50, 370, 80, 30);
        panel.add(enterButton);

        Button displayAllButton = new Button("Display All");
        displayAllButton.setBounds(150, 370, 80, 30);
        panel.add(displayAllButton);

        Button searchButton = new Button("Search");
        searchButton.setBounds(250, 370, 80, 30);
        panel.add(searchButton);

        Button exitButton = new Button("Exit");
        exitButton.setBounds(350, 370, 80, 30);
        panel.add(exitButton);

        frame.setVisible(true);

        // Create the event handler and pass the necessary components
        PizzaEventHandler eventHandler = new PizzaEventHandler(name1, toppings, sizeGroup, billTextArea, frame);

        // Add action listeners to the buttons
        enterButton.addActionListener(e -> eventHandler.handleEnter());
        displayAllButton.addActionListener(e -> eventHandler.handleDisplayAll());
        exitButton.addActionListener(e -> eventHandler.handleExit());

        // Add action listener to the search button
        searchButton.addActionListener(e -> {
            String customerName = name1.getText();
            eventHandler.handleSearch(customerName);
        });

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                frame.dispose();
            }
        });
    }
}
