package javaSwingComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class calculateSumAndDifference{

    public static void main(String[] args) {
        // Create a new frame
        JFrame frame = new JFrame("Sum and Difference Calculator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 200);

        
        frame.setLayout(new GridLayout(3, 2));
        
   
        JLabel number1Label = new JLabel("Number 1: ");
        JTextField number1TextField = new JTextField();
        JLabel number2Label = new JLabel("Number 2: ");
        JTextField number2TextField = new JTextField();
        JLabel resultLabel = new JLabel("Result: ");
        JLabel resultValueLabel = new JLabel();
        
      
        MouseAdapter mouseAdapter = new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                try {
                   
                    double num1 = Double.parseDouble(number1TextField.getText());
                    double num2 = Double.parseDouble(number2TextField.getText());
                    
              
                    double sum = num1 + num2;
                    
                  resultValueLabel.setText(String.format("%.2f", sum));
                } catch (NumberFormatException ex) {
            
                    resultValueLabel.setText("Invalid input");
                }
            }

            @Override
            public void mouseReleased(MouseEvent e) {
                try {
               
                    double num1 = Double.parseDouble(number1TextField.getText());
                    double num2 = Double.parseDouble(number2TextField.getText());
                    
            
                    double difference = num1 - num2;
                    
           
                    resultValueLabel.setText(String.format("%.2f", difference));
                } catch (NumberFormatException ex) {
              
                    resultValueLabel.setText("Invalid input");
                }
            }
        };
        
 
        frame.addMouseListener(mouseAdapter);
        
   
        frame.add(number1Label);
        frame.add(number1TextField);
        frame.add(number2Label);
        frame.add(number2TextField);
        frame.add(resultLabel);
        frame.add(resultValueLabel);
        

        frame.setVisible(true);
    }
}
