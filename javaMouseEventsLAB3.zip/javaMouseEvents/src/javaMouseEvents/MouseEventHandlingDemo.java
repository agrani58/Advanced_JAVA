package javaMouseEvents;

import javax.swing.*;
import java.awt.*;

public class MouseEventHandlingDemo {
    
    public MouseEventHandlingDemo() {
        JFrame f = new JFrame("Login Form");
        
        JLabel jlabel1 = new JLabel("Name:");
        JLabel jlabel2 = new JLabel("Email:");
        
        JTextField txt1 = new JTextField();
        JTextField txt2 = new JTextField();
        
        // Load and resize the first image
        ImageIcon originalIcon1 = new ImageIcon("C:\\Users\\agran\\OneDrive\\Desktop\\download.jpg");
        Image resizedImage1 = originalIcon1.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon1 = new ImageIcon(resizedImage1);
        JLabel imageLabel1 = new JLabel(resizedIcon1);
        
        // Load and resize the second image
        ImageIcon originalIcon2 = new ImageIcon("C:\\Users\\agran\\OneDrive\\Desktop\\download.jpg");
        Image resizedImage2 = originalIcon2.getImage().getScaledInstance(30, 30, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon2 = new ImageIcon(resizedImage2);
        JLabel imageLabel2 = new JLabel(resizedIcon2);
        
        // Set layout to null for absolute positioning
        f.setLayout(null);
        
        // Set bounds for the components
        jlabel1.setBounds(50, 50, 100, 30);
        txt1.setBounds(150, 50, 150, 30);
        imageLabel1.setBounds(310, 50, 30, 30);
        
        jlabel2.setBounds(50, 100, 100, 30);
        txt2.setBounds(150, 100, 150, 30);
        imageLabel2.setBounds(310, 100, 30, 30);
        
        // Add components to the frame
        f.add(jlabel1);
        f.add(txt1);
        f.add(imageLabel1);
        f.add(jlabel2);
        f.add(txt2);
        f.add(imageLabel2);
        
        f.setSize(400, 300); // Adjusted size to fit all components
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    public static void main(String[] args) {
        new MouseEventHandlingDemo();
    }
}
