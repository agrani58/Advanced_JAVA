package javaMouseEvents;

import java.awt.*;
import java.awt.event.*;

public class mouseEvents {

 

    public mouseEvents() {
        Frame frame = new Frame("Java MouseEvent Examples");
        frame.setSize(400, 400);


       Label enter = new Label("Mouse", Label.CENTER);

       frame.setLayout(new GridLayout(2, 2));

        
       frame.addMouseListener(new MouseListener() {
           public void mouseClicked(MouseEvent e) {
            enter.setText("MouseClicked (" + e.getX() + ", " + e.getY() + ")"+frame.getSize().getHeight()+frame.getSize().getWidth());
           }
           public void mousePressed(MouseEvent e) {
           }
           public void mouseReleased(MouseEvent e) {
           }
           public void mouseEntered(MouseEvent e) {
            enter.setText("Mouse Entered:");
           }
           public void mouseExited(MouseEvent e) {
        	   enter.setText("Mouse Exited:");
           }
       }); 
             
        frame.add(enter);
        frame.setVisible(true);
        
        frame.addWindowListener(new WindowAdapter() {
        	public void windowClosing(WindowEvent e) {
        		frame.dispose();
        	}

        });
    }

    public static void main(String[] args) {
        new mouseEvents();
    }
} 