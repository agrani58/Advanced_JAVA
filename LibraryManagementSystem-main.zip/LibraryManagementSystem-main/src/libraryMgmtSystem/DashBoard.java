package libraryMgmtSystem;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.JScrollPane;
import java.sql.Timestamp;

public class DashBoard implements ActionListener {

// Database credentials
private static final String DB_URL = "jdbc:mysql://localhost:3306/library_mgmt_system";
private static final String DB_USER = "root";
private static final String DB_PASSWORD = ""; // Replace with your actual MySQL password

// Components for Add Student tab
JButton btnAddStudent;
JTextField txtFName;
JTextField txtLName;
JTextField txtBook;
JRadioButton radioMale;
JRadioButton radioFemale;
JComboBox<String> comboProgram;
JComboBox<String> comboSection;

// Components for Display Records tab
JTable table;
DefaultTableModel tableModel;

// Components for Add Book tab
JButton btnAddBook;
JTextField txtAuthor;
JTextField txtTitle;
JTextField txtPublication;
JTextField txtSubject;

// Components for Issue Book tab
JButton btnIssueBook;
JTextField txtStudentName;  // Changed to student name for lookup
JTextField txtBookTitle;    // Changed to book title for lookup
JTextField txtIssueDate;    // Added for issue date
JTextField txtDueDate;

public DashBoard() {
    JFrame jf = new JFrame("Library Management System");
    JTabbedPane tabbedPane = new JTabbedPane();

    // First tab - Add Student
    JPanel addStudentPanel = createAddStudentPanel();
    tabbedPane.addTab("Add Student", addStudentPanel);

    // Second tab - Display Records
    JPanel displayRecordsPanel = createDisplayRecordsPanel();
    tabbedPane.addTab("Display Records", displayRecordsPanel);
    displayRecords();  // Automatically display records

    // Third tab - Add Book
    JPanel addBookPanel = createAddBookPanel();
    tabbedPane.addTab("Add Book", addBookPanel);

    // Fourth tab - Issue Book
    JPanel issueBookPanel = createIssueBookPanel();
    tabbedPane.addTab("Issue Book", issueBookPanel);

    // Setting frame properties
    jf.setContentPane(tabbedPane);
    jf.setSize(600, 400);
    jf.setVisible(true);
    jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

private JPanel createAddStudentPanel() {
    JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));
    panel.setBorder(new EmptyBorder(10, 10, 10, 15));

    // Creating components
    JLabel lblFName = new JLabel("First Name:");
    JLabel lblLName = new JLabel("Last Name:");
    JLabel lblProgram = new JLabel("Program:");
    JLabel lblGender = new JLabel("Gender:");
    JLabel lblBook = new JLabel("Book Taken:");
    JLabel lblSection = new JLabel("Section:");

    txtFName = new JTextField(10);
    txtLName = new JTextField(10);
    txtBook = new JTextField(10);

    radioMale = new JRadioButton("Male");
    radioFemale = new JRadioButton("Female");
    ButtonGroup genderGroup = new ButtonGroup();
    genderGroup.add(radioMale);
    genderGroup.add(radioFemale);

    comboProgram = new JComboBox<>(new String[]{"BBA", "BBA-TT", "BCIS", "BBA-BI"});
    comboSection = new JComboBox<>();

    btnAddStudent = new JButton("Add Student");
    btnAddStudent.addActionListener(this);

    // Adding components to panel
    panel.add(lblFName);
    panel.add(txtFName);
    panel.add(lblLName);
    panel.add(txtLName);
    panel.add(lblGender);
    panel.add(createGenderPanel());
    panel.add(lblProgram);
    panel.add(comboProgram);
    panel.add(lblSection);
    panel.add(comboSection);
    panel.add(lblBook);
    panel.add(txtBook);   
    panel.add(btnAddStudent);

    // Handling program selection changes to update sections
    comboProgram.addItemListener(e -> {
        if (e.getStateChange() == ItemEvent.SELECTED) {
            updateSections((String) e.getItem());
        }
    });

    // Initialize sections for the default selected program
    updateSections((String) comboProgram.getSelectedItem());

    return panel;
}

private JPanel createGenderPanel() {
    JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
    panel.add(radioMale);
    panel.add(radioFemale);
    return panel;
}

private void updateSections(String program) {
    comboSection.removeAllItems();
    switch (program) {
        case "BCIS":
            comboSection.addItem("Grit/Garnet");
            comboSection.addItem("Fusion");
            comboSection.addItem("Fourier");
            comboSection.addItem("Enum/Efika");
            comboSection.addItem("Devine/Deism");
            comboSection.addItem("Maxthon");
            break;
        case "BBA-BI":
            comboSection.addItem("Trend");
            comboSection.addItem("Transit");
            comboSection.addItem("Forex");
            comboSection.addItem("Fiscal");
            break;
        case "BBA":
            comboSection.addItem("Jasper");
            comboSection.addItem("Jasmin");
            comboSection.addItem("Icon");
            comboSection.addItem("Image");
            comboSection.addItem("Ideal");
            comboSection.addItem("helm");
            break;
        default:
      
            break;
    }
}

private JPanel createDisplayRecordsPanel() {
    JPanel panel = new JPanel(new BorderLayout());
    
    tableModel = new DefaultTableModel();
    tableModel.addColumn("First Name");
    tableModel.addColumn("Last Name");
    tableModel.addColumn("Gender");
    tableModel.addColumn("Program");
    tableModel.addColumn("Section");
    tableModel.addColumn("Book Taken");

    table = new JTable(tableModel);
    JScrollPane scrollPane = new JScrollPane(table);

    panel.add(scrollPane, BorderLayout.CENTER);

    return panel;
}

private JPanel createAddBookPanel() {
    JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));

    // Creating components
    JLabel lblAuthor = new JLabel("Author:");
    JLabel lblTitle = new JLabel("Title:");
    JLabel lblPublication = new JLabel("Publication:");
    JLabel lblSubject = new JLabel("Subject:");

    txtAuthor = new JTextField(10);
    txtTitle = new JTextField(10);
    txtPublication = new JTextField(10);
    txtSubject = new JTextField(10);

    btnAddBook = new JButton("Add Book");
    btnAddBook.addActionListener(this);

    // Adding components to panel
    panel.add(lblAuthor);
    panel.add(txtAuthor);
    panel.add(lblTitle);
    panel.add(txtTitle);
    panel.add(lblPublication);
    panel.add(txtPublication);
    panel.add(lblSubject);
    panel.add(txtSubject); 
    panel.add(btnAddBook);

    return panel;
}

private JPanel createIssueBookPanel() {
    JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));  // Updated GridLayout to 5 rows
 

    // Creating components
    JLabel lblStudentName = new JLabel("Student Name:");
    JLabel lblBookTitle = new JLabel("Book Title:");
    JLabel lblIssueDate = new JLabel("Issue Date (yyyy-mm-dd ):");
    JLabel lblDueDate = new JLabel("Due Date (yyyy-mm-dd):");

    txtStudentName = new JTextField(10);
    txtBookTitle = new JTextField(10);
    txtIssueDate = new JTextField(10);  // Added for issue date
    txtDueDate = new JTextField(10);

    btnIssueBook = new JButton("Issue Book");
    btnIssueBook.addActionListener(this);

    // Adding components to panel
    panel.add(lblStudentName);
    panel.add(txtStudentName);
    panel.add(lblBookTitle);
    panel.add(txtBookTitle);
    panel.add(lblIssueDate);
    panel.add(txtIssueDate);  // Added to panel
    panel.add(lblDueDate);
    panel.add(txtDueDate);

    panel.add(btnIssueBook);

    return panel;
}

@Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == btnAddStudent) {
        addStudent();
    } else if (e.getSource() == btnAddBook) {
        addBook();
    } else if (e.getSource() == btnIssueBook) {
        issueBook();
    }
}

private void addStudent() {
    String fName = txtFName.getText();
    String lName = txtLName.getText();
    String gender = radioMale.isSelected() ? "Male" : "Female";
    String program = (String) comboProgram.getSelectedItem();
    String section = (String) comboSection.getSelectedItem();
    String book = txtBook.getText();

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        String query = "INSERT INTO student (firstName, lastName, gender, program, section, bookTaken) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, fName);
        stmt.setString(2, lName);
        stmt.setString(3, gender);
        stmt.setString(4, program);
        stmt.setString(5, section);
        stmt.setString(6, book);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            JOptionPane.showMessageDialog(null, "Student added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            displayRecords();  // Refresh the display records
        } else {
            JOptionPane.showMessageDialog(null, "Failed to add student.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void displayRecords() {
    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        String query = "SELECT * FROM student";
        PreparedStatement stmt = conn.prepareStatement(query);
        ResultSet rs = stmt.executeQuery();

        tableModel.setRowCount(0); // Clear existing rows

        while (rs.next()) {
            String fName = rs.getString("firstName");
            String lName = rs.getString("lastName");
            String gender = rs.getString("gender");
            String program = rs.getString("program");
            String section = rs.getString("section");
            String book = rs.getString("bookTaken");
            tableModel.addRow(new Object[]{fName, lName, gender, program, section, book});
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void addBook() {
    String author = txtAuthor.getText();
    String title = txtTitle.getText();
    String publication = txtPublication.getText();
    String subject = txtSubject.getText();

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        String query = "INSERT INTO book (author, title, publication, subject) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.setString(1, author);
        stmt.setString(2, title);
        stmt.setString(3, publication);
        stmt.setString(4, subject);
        int rows = stmt.executeUpdate();

        if (rows > 0) {
            JOptionPane.showMessageDialog(null, "Book added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to add book.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void issueBook() {
    String studentName = txtStudentName.getText();
    String bookTitle = txtBookTitle.getText();
    String issueDateStr = txtIssueDate.getText();
    String dueDateStr = txtDueDate.getText();

    try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
        // Retrieve student ID
        String studentQuery = "SELECT id FROM student WHERE firstName = ?";
        PreparedStatement studentStmt = conn.prepareStatement(studentQuery);
        studentStmt.setString(1, studentName);
        ResultSet studentRs = studentStmt.executeQuery();
        if (!studentRs.next()) {
            JOptionPane.showMessageDialog(null, "Student not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int studentId = studentRs.getInt("id");

        // Retrieve book ID
        String bookQuery = "SELECT id FROM book WHERE title = ?";
        PreparedStatement bookStmt = conn.prepareStatement(bookQuery);
        bookStmt.setString(1, bookTitle);
        ResultSet bookRs = bookStmt.executeQuery();
        if (!bookRs.next()) {
            JOptionPane.showMessageDialog(null, "Book not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        int bookId = bookRs.getInt("id");

        // Parse issueDate and dueDate strings to java.sql.Date
        java.sql.Date issueDate = null;
        java.sql.Date dueDate = null;

        try {
            issueDate = java.sql.Date.valueOf(issueDateStr);
            dueDate = java.sql.Date.valueOf(dueDateStr);
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(null, "Invalid date format. Please use yyyy-mm-dd", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert into book_issue
        String issueQuery = "INSERT INTO book_issue (student_id, book_id, issueDate, dueDate) VALUES (?, ?, ?, ?)";
        PreparedStatement issueStmt = conn.prepareStatement(issueQuery);
        issueStmt.setInt(1, studentId);
        issueStmt.setInt(2, bookId);
        issueStmt.setDate(3, issueDate);
        issueStmt.setDate(4, dueDate);
        int rows = issueStmt.executeUpdate();

        if (rows > 0) {
            JOptionPane.showMessageDialog(null, "Book issued successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to issue book.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}



public static void main(String[] args) {
    new DashBoard();
}
}