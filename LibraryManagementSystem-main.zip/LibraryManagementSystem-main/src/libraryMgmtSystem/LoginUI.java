package libraryMgmtSystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class LoginUI {
    JTextField userNameField;
    JPasswordField passwordField;
    private static final String DB_URL = "jdbc:mysql://localhost:3306/library_mgmt_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // Replace with your actual MySQL password

    public LoginUI() {
        JFrame jf = new JFrame("Login Module");

        // Creating the panels
        JPanel p1 = new JPanel(new GridLayout(2, 2, 10, 10));
        JPanel p2 = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Creating components for p1
        JLabel jl = new JLabel("User Name: ");
        JLabel jl3 = new JLabel("Password: ");
        userNameField = new JTextField(10);
        passwordField = new JPasswordField(10);

        // Setting size and font for p1 components
        jl.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        jl3.setFont(new Font("Times New Roman", Font.PLAIN, 16));

        // Adding components to p1
        p1.add(jl);
        p1.add(userNameField);
        p1.add(jl3);
        p1.add(passwordField);

        // Creating buttons for p2 and setting preferred size
        JButton signBtn = new JButton("Sign In");
        JButton registerBtn = new JButton("Register");
        JButton cancelBtn = new JButton("Cancel");

        Dimension buttonSize = new Dimension(120, 30);
        signBtn.setPreferredSize(buttonSize);
        registerBtn.setPreferredSize(buttonSize);
        cancelBtn.setPreferredSize(buttonSize);

        // Adding buttons to p2
        p2.add(signBtn);
        p2.add(registerBtn);
        p2.add(cancelBtn);

        // Adding action listeners for buttons
        signBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userName = userNameField.getText();
                String password = new String(passwordField.getPassword());

                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String query = "SELECT * FROM users WHERE username = ? AND password = ?";
                    PreparedStatement stmt = conn.prepareStatement(query);
                    stmt.setString(1, userName);
                    stmt.setString(2, password);
                    ResultSet rs = stmt.executeQuery();

                    if (rs.next()) {
                        new DashBoard(); // Display the dashboard upon successful login
                        jf.dispose();
                        JOptionPane.showMessageDialog(null, "Username and password matched", "Status", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Username and password didn't match", "Status", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        registerBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userName = userNameField.getText();
                String password = new String(passwordField.getPassword());

                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Check if username already exists
                    String checkQuery = "SELECT * FROM users WHERE username = ?";
                    PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
                    checkStmt.setString(1, userName);
                    ResultSet checkRs = checkStmt.executeQuery();

                    if (checkRs.next()) {
                        JOptionPane.showMessageDialog(null, "Username already exists", "Status", JOptionPane.WARNING_MESSAGE);
                    } else {
                        // Insert new user
                        String query = "INSERT INTO users (username, password) VALUES (?, ?)";
                        PreparedStatement stmt = conn.prepareStatement(query);
                        stmt.setString(1, userName);
                        stmt.setString(2, password);
                        stmt.executeUpdate();
                        JOptionPane.showMessageDialog(null, "User registered successfully", "Status", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        cancelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                jf.dispose(); // Close the application
            }
        });

        // Setting frame properties and adding panels
        jf.setLayout(new GridLayout(2, 1));
        jf.add(p1);
        jf.add(p2);
        jf.setSize(400, 200);
        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new LoginUI();
    }
}
