package libraryMgmtSystem;

public class LibraryManagementSystem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			LoginUI sbd = new LoginUI();

	}

}
