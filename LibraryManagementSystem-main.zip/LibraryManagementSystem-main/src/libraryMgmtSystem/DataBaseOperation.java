package libraryMgmtSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class DataBaseOperation {
    // Database credentials
    private static final String DB_URL = "jdbc:mysql://localhost:3306/library_mgmt_system";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = ""; // Replace with your actual MySQL password

    // Method to write Student data to the database
    public void writeStudentData(Student student) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO student (firstName, lastName, gender, program, section, bookTaken) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, student.getFirstName());
            stmt.setString(2, student.getLastName());
            stmt.setString(3, student.getGender());
            stmt.setString(4, student.getProgram());
            stmt.setString(5, student.getSection());
            stmt.setString(6, student.getBookTaken());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Method to read all Students from the database
    public List<Student> readStudent() {
        List<Student> students = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM student";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setId(rs.getInt("id"));
                student.setFirstName(rs.getString("firstName"));
                student.setLastName(rs.getString("lastName"));
                student.setGender(rs.getString("gender"));
                student.setProgram(rs.getString("program"));
                student.setSection(rs.getString("section"));
                student.setBookTaken(rs.getString("bookTaken"));
                students.add(student);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return students;
    }

    // Method to write Book data to the database
    public void writeBookData(Book book) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO book (author, title, publication, subject) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, book.getAuthor());
            stmt.setString(2, book.getTitle());
            stmt.setString(3, book.getPublication());
            stmt.setString(4, book.getSubject());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Method to read all Books from the database
    public List<Book> readBook() {
        List<Book> books = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM book";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Book book = new Book();
                book.setId(rs.getInt("id"));
                book.setAuthor(rs.getString("author"));
                book.setTitle(rs.getString("title"));
                book.setPublication(rs.getString("publication"));
                book.setSubject(rs.getString("subject"));
                books.add(book);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return books;
    }

    // Method to write BookIssue data to the database
    public void writeBookIssued(BookIssue bookIssue) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO book_issue (student_id, book_id, issueDate, dueDate) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, bookIssue.getStudentId());
            stmt.setInt(2, bookIssue.getBookId());
            stmt.setTimestamp(3, bookIssue.getIssueDate());
            stmt.setTimestamp(4, bookIssue.getDueDate());
            stmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    // Method to read all BookIssues from the database
    public List<BookIssue> readBookIssue() {
        List<BookIssue> bookIssues = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM book_issue";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                BookIssue bookIssue = new BookIssue();
                bookIssue.setId(rs.getInt("id"));
                bookIssue.setStudentId(rs.getInt("student_id"));
                bookIssue.setBookId(rs.getInt("book_id"));
                bookIssue.setIssueDate(rs.getTimestamp("issueDate"));
                bookIssue.setDueDate(rs.getTimestamp("dueDate"));
                bookIssues.add(bookIssue);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return bookIssues;
    }
}
